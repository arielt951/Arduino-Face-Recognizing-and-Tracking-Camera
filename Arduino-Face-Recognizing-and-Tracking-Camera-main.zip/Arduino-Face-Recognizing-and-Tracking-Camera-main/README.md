# Arduino-Face-Recognizing-and-Tracking-Camera
We built a system that combines the Arduino controller to perform simple operations using engine components together with the OpenCv library of Python which has a high computational capacity.
